cccc
TA_header

fesn1 =([num2str(TAT1),'_TA.mat']);
fesn2 =([num2str(TAT2),'_TA.mat']);
fesn3 =([num2str(TAT3),'_TA.mat']);
fesn4 =([num2str(TAT4),'_TA.mat']);
fesn5 =([num2str(TAT5),'_TA.mat']);
fesn6 =([num2str(TAT6),'_TA.mat']);
fesn7 =([num2str(TAT7),'_TA.mat']);
fesn8 =([num2str(TAT8),'_TA.mat']);
fesn9 =([num2str(TAT9),'_TA.mat']);
fesn10=([num2str(TAT10),'_TA.mat']);
fesn11=([num2str(TAT11),'_TA.mat']);
fesn12=([num2str(TAT12),'_TA.mat']);
fesn13=([num2str(TAT13),'_TA.mat']);
fesn14=([num2str(TAT14),'_TA.mat']);
fesn15=([num2str(TAT15),'_TA.mat']);
fesn16=([num2str(TAT16),'_TA.mat']);
fesn17=([num2str(TAT17),'_TA.mat']);
fesn18=([num2str(TAT18),'_TA.mat']);
fesn19=([num2str(TAT19),'_TA.mat']);
