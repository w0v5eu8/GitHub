clear
clc
close all