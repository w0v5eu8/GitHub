function x = minusPoint5(y)
% a little helper used in generateNet, just subtracts 0.5
x = y - 0.5;