function y=fInverse(x)
%inverse of the activation function f: Arctanh(x) or identity or
%custom-made according to your chosen f
y=atanh(x);
% y = x;