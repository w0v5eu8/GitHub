if connectivity*10 == 1
corr1=corr;
profit1=profit;
no_ss1=no_ss;
buy_esn1=buy_esn;
sell_esn1=sell_esn;
buy_n_sell1=buy_n_sell;
SIM_x1=SIM_x;
net1=net;
prr_esn1=prr_esn;
no1=no;
elseif connectivity*10 == 2
corr2=corr;
profit2=profit;
no_ss2=no_ss;
buy_esn2=buy_esn;
sell_esn2=sell_esn;
buy_n_sell2=buy_n_sell;
SIM_x2=SIM_x;
net2=net;
prr_esn2=prr_esn;
no2=no;
elseif connectivity*10 == 3
corr3=corr;
profit3=profit;
no_ss3=no_ss;
buy_esn3=buy_esn;
sell_esn3=sell_esn;
buy_n_sell3=buy_n_sell;
SIM_x3=SIM_x;
net3=net;
prr_esn3=prr_esn;
no3=no;
end
