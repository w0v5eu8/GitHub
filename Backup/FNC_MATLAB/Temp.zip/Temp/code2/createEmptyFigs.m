close all
fig1 = figure('Position',[100,480,300,200]);
fig2 = figure('Position',[750,480,300,200]);
fig3 = figure('Position',[750,80,300,200]);
fig4 = figure('Position',[1075,480,300,200]);

fig5 = figure('Position',[100,80,600,300]);

fig6 = figure('Position',[425,480,300,200]);


% fig7 = figure('Position',[1,40,400,300]);fig8 = figure('Position',[1,40,400,300]);
% fig9 = figure('Position',[1,40,400,300]);fig10 = figure('Position',[1,40,400,300]);
% fig11 = figure('Position',[1,40,400,300]);fig12 = figure('Position',[1,40,400,300]);